use TinyTheaters;

    insert into Customer(
    CustomerEmail,
    CustomerFirst,
    CustomerLast,
    CustomerPhone,
    CustomerAddress
    )
    select distinct
    customer_email,
    customer_first,
    customer_last,
    customer_phone,
    Customer_address
    from [rcttc-data];

    select*
    from Customer;

    /* Show */

    insert into Show(
    ShowName,
    ShowDate,
    TheaterId
    )
    select distinct
    d.show,
    d.date,
    t.TheaterId
    from Theater t
    inner join [rcttc-data] d on d.Theater = t.TheaterName
    
    select*
    from Show;
    
    /*Theater*/

    insert into Theater(
    TheaterName,
    TheaterAddress,
    TheatherPhone,
    TheaterEmail
    )
    select distinct
    theater,
    theater_address,
    theater_phone,
    theater_email
    from [rcttc-data];

    select*
    from Theater;

    /*Ticket*/

    insert into Ticket(
        TicketPrice,
        Seat,
        ShowDate,
        ShowName,
        CustomerId
    )
    select distinct 
        d.ticket_price,
        d.seat,
        d.date,
        d.show,
        c.CustomerId
        from [rcttc-data] d
        inner join customer c on d.customer_email = c.CustomerEmail
        
    /*Ticket price change*/

    select *
    from Ticket
    where ShowDate = '2021-03-01' and ShowName = 'The Sky Lit Up';

    update ticket set TicketPrice = 22.25
    where ShowDate = '2021-03-01' and ShowName = 'The Sky Lit Up';
  

    /*Adjust Seating*/
    update ticket set 
    seat = 'B1'
    where TicketId = 91;

    update ticket set
    seat = 'B2'
    where TicketId = 92;

    update ticket set
    seat = 'B3'
    where TicketId = 93;

    update ticket set
    seat = 'B4'
    where TicketId = 94;

    update ticket set
    seat = 'C1'
    where TicketId = 95;

    update ticket set
    seat = 'C2'
    where TicketId = 96;

    update ticket set
    seat = 'A4'
    where TicketId = 97;

    /*update Jammie phone #*/

    update customer set 
    CustomerPhone = '1-800-EAT-CAKE'
    where CustomerEmail = 'jswindlesd9@studiopress.com';

    select* from Customer where CustomerLast = 'Swindles'

    /*Delete single tickets for 10 pin*/

    select  
    t.ShowName,
    t.ShowDate,
    c.CustomerLast,
    th.TheaterName
    from ticket t 
    inner join  show s on t.ShowDate = s.ShowDate and t.ShowName = s.ShowName
    inner join Theater th on th.TheaterName = th.TheaterName
    inner join Customer c on c.CustomerId = t.CustomerId
    where th.TheaterName = '10 Pin'

    delete from ticket
    where ShowDate = '2021-03-01' and CustomerId = '2';
    
    delete from ticket
    where ShowDate = '2021-09-24' and CustomerId = '22';

    delete from ticket
    where ShowDate = '2021-09-24' and CustomerId = '25';

    delete from ticket
    where ShowDate = '2021-09-24' and CustomerId = '37';

    delete from ticket
    where ShowDate = '2021-01-04' and CustomerId = '44';

    delete from ticket
    where ShowDate = '2021-01-04' and CustomerId = '45';

    delete from ticket
    where ShowDate = '2021-09-24' and CustomerId = '55';

    delete from ticket
    where ShowDate = '2021-01-04' and CustomerId = '63';

    delete from ticket
    where ShowDate = '2021-12-21' and CustomerId = '64';


    /*Delete Liv Egle (elaborate joke)*/
    select * from customer where CustomerFirst ='Liv';
    delete from ticket where CustomerId = 65;
    delete from customer where CustomerEmail = 'legleofgermanybh@blinklist.com';


 


