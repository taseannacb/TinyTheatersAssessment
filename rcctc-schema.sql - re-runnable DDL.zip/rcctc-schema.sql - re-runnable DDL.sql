use master;
go
drop database if exists TinyTheaters;
go
create database TinyTheaters;
go
use TinyTheaters;
go


create table Customer (
    CustomerId int primary key identity(1,1),
	CustomerEmail varchar(50) not null,
    CustomerFirst varchar(25) not null,
    CustomerLast varchar(25) not null,
    CustomerPhone varchar(25) null,
    CustomerAddress varchar(50) null
    );       

create table Ticket (
	TicketId int primary key identity(1,1),
    TicketPrice decimal(4,2) not null,
    Seat varchar(2) not null,
    ShowDate date not null,
    ShowName varchar(100) not null,
    CustomerId int not null,
    constraint fk_Ticket_CustomerId
    foreign key (CustomerId)
    references Customer(CustomerId)
);

create table Theater (
    TheaterId int primary key identity(1,1),
	TheaterName varchar(25),
    TheaterAddress varchar(100) not null,
    TheatherPhone varchar(25) not null,
    TheaterEmail varchar(50) not null,
    CustomerId int not null
    constraint fk_Theater_ShowId
    foreign key (ShowId)
    references Show(ShowId)
);

create table Show (
	ShowId int primary key identity(1,1),
	ShowName varchar(50),
    ShowDate date not null,
    TheaterId int not null,
    constraint fk_Show_TheaterId
    foreign key (TheaterId)
    references Theater(TheaterId)
);

