use TinyTheaters

/*Last quater performances*/
select 
ShowDate,
ShowName
from Show
where ShowDate between '2021-10-01' and '2021-12-31'

/*No customer diplication*/
select distinct*
from customer 

/*Find customers without .com email*/
select distinct*
from customer 
where CustomerEmail like '%.com';

/*Find 3 cheapest shows*/
select distinct 
ShowName,
TicketPrice
from Ticket
order by TicketPrice
limit 3;

/*list customer with dupes showing they are attending*/
select distinct 
c.CustomerFirst,
c.CustomerLast,
t.CustomerEmail,
t.ShowName
from customer c 
inner join ticket t on c.CustomerEmail = t.CustomerEmail;

/* ticket info one query*/
select distinct 
concat (c.CustomerFirst, ' ', c.CustomerLast) as Customer,
s.ShowName,
s.ShowDate,
t.TheaterName,
t.seat
from ticket t
inner join customer c on c.CustomerEmail = t.CustomerEmail
inner join show s on s.ShowName = t.ShowName
order by s.ShowDate;

/*Find cus. without addr.*/
select*
from customer 
where CustomerAddress = '';

/*Recreate the spreadsheet data with single query*/
select 
c.CustomerFirst,
c.CustomerLast,
c.CustomerEmail,
c.CustomerPhone,
c.CustomerAddress,
t.seat,
t.ShowName,
t.TicketPrice,
t.ShowDate,
t.ShowName,
s.TheaterName,
th.TheaterAddress,
th.TheatherPhone,
th.TheaterEmail
from ticket t 
inner join customer c on t.CustomerEmail = c.CustomerEmail
inner join show s on t.ShowName = s.ShowName and t.ShowDate = s.ShowDate
inner join theater th on s.TheaterName = th.TheaterName;

/*Count total tickets purchased per customer*/
select count(*) as TotalTickets,
CustomerEmail
from ticket
group by CustomerEmail
order by count(*) desc;

/*Calculate total revenue per show based on tickets sold*/
select 
count(TicketId) * TicketPrice as 'total revenue',
ShowName,
ShowDate
from ticket 
group by ShowName AND ShowDate;


